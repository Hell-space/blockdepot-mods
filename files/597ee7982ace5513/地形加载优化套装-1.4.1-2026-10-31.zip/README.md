# 地形加载优化套装 1.4.1

Minecraft 1.21.1 / NeoForge 21.1.252 / Java 21。

本机已安装到 `D:\Minecraft\.minecraft\versions\1.21.1-NeoForge_21.1.248`，下次使用原 PCL 入口启动即可。套装内为 ThreadPilot 1.4.1、存档快照 1.6.4、内存织理 1.1.0、LoadPilot 1.0.0。

本轮主要减少存档快照冻结区块与预加载比较的额外计数/初始化，并修复共享调色板编码和恢复的并发异常。ThreadPilot 保留已验证的原自动预算；本机为后台 26、Sodium 4。地形生成、画质、视距和 Sodium 配置保持原有行为。上述地形收益需要同时更新存档快照 1.6.4，单独更新 ThreadPilot 不代表获得整套对照的效果。

真实 119 模组整合包平均目标批次完成时间 6.377 → 6.283 秒，缩短约 1.49%。扣除传送前排队后仅改善 0.69%，幅度有限；完整分阶段结果和限制见 RESULTS-1.4.1.md。正式模组不包含 QA 自动测试代码。

重新安装可双击 `install.cmd`。先关闭目标 Minecraft；脚本核对已验收 SHA256，只替换四个项目 JAR，备份旧 JAR，保留其他模组、所有设置及存档。安装不会启动游戏。`install.cmd --prepare-only` 仅预览；其他同平台实例可用 `install.cmd --instance "实例绝对路径"` 指定。CMD 为 ASCII/CRLF，成功和报错后等待输入。

本机旧包备份：`D:\zcodes\我的世界优化mod\work\installed-terrain-previous\20261031-014121-991645`。需要回退时关闭游戏，移出这四个项目的当前 JAR，再将备份 `mods` 中四个 JAR 复制回原实例 `mods`；其余模组保留。

`VERIFIED.json` 记录最终四件套的版本与 SHA256，`comparison.json` 保存最终比较。独立源码压缩包包含四项目、QA 源码和结构化证据；复现实测还需要本机合法 Minecraft 安装与同一整合包，游戏本体、第三方模组、账户配置和玩家存档不随源码分发。

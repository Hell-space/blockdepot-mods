"""Install the verified quartet while preserving all player settings and worlds."""
from __future__ import annotations
import argparse
from datetime import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import tomllib
import zipfile

ROOT=Path(__file__).resolve().parents[1]
IDS={'threadpilot','memoryweave','savesnapshots','loadpilot'}

def digest(path): return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2),encoding='utf-8')
def identities(path):
    with zipfile.ZipFile(path) as jar:
        if 'META-INF/neoforge.mods.toml' not in jar.namelist(): return set()
        data=tomllib.loads(jar.read('META-INF/neoforge.mods.toml').decode('utf-8-sig'))
        return {mod['modId'] for mod in data.get('mods',[])}

def require_closed_jar(path):
    # Sodium can hide the JVM command line after startup. Check the actual JAR
    # handle as well, so that a hidden game cannot bypass the process check.
    if os.name!='nt':return
    import ctypes
    from ctypes import wintypes
    kernel=ctypes.WinDLL('kernel32',use_last_error=True)
    kernel.CreateFileW.argtypes=[wintypes.LPCWSTR,wintypes.DWORD,wintypes.DWORD,
        wintypes.LPVOID,wintypes.DWORD,wintypes.DWORD,wintypes.HANDLE]
    kernel.CreateFileW.restype=wintypes.HANDLE
    kernel.CloseHandle.argtypes=[wintypes.HANDLE]
    handle=kernel.CreateFileW(str(path),0x80000000,4,None,3,0,None)
    if handle==wintypes.HANDLE(-1).value:
        raise RuntimeError('Close the target game or program using this JAR before installation: '+str(path))
    kernel.CloseHandle(handle)
def running_target(instance):
    script="[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new($false)\nGet-CimInstance Win32_Process -Filter \"Name='java.exe' OR Name='javaw.exe'\" | Select-Object ProcessId,CommandLine | ConvertTo-Json -Compress"
    completed=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],capture_output=True,check=True)
    text=completed.stdout.decode('utf-8-sig',errors='replace').strip()
    if not text:return []
    rows=json.loads(text);rows=rows if isinstance(rows,list) else [rows]
    found=[]
    for row in rows:
        match=re.search(r'--gameDir(?:=|\s+)(?:"([^"]+)"|(\S+))',row.get('CommandLine') or '')
        if match:
            directory=Path(match[1] or match[2])
            if directory.is_absolute() and directory.resolve()==instance:found.append(row['ProcessId'])
    return found

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--instance',type=Path,default=Path(r'D:\Minecraft\.minecraft\versions\1.21.1-NeoForge_21.1.248'))
    parser.add_argument('--bundle',type=Path,default=ROOT/'dist/地形加载优化套装-1.4.1-2026-10-31')
    parser.add_argument('--prepare-only',action='store_true')
    args=parser.parse_args()
    instance=args.instance.resolve(strict=True);bundle=args.bundle.resolve(strict=True)
    mods=(instance/'mods').resolve(strict=True)
    receipt=json.loads((bundle/'VERIFIED.json').read_text(encoding='utf-8-sig'))
    if receipt.get('passed') is not True or {mod['id'] for mod in receipt['mods']}!=IDS or len(receipt['mods'])!=4:
        raise RuntimeError('The bundle must contain four accepted production mods')
    versions=[]
    for file in instance.glob('*.json'):
        try:data=json.loads(file.read_text(encoding='utf-8-sig'))
        except (UnicodeError,json.JSONDecodeError):continue
        if not isinstance(data,dict):continue
        if data.get('inheritsFrom')=='1.21.1' or data.get('id')=='1.21.1':versions.append(data)
    if not versions and not instance.name.startswith('1.21.1-'):
        raise RuntimeError('The target instance is not identified as Minecraft 1.21.1')
    active=running_target(instance)
    if active:raise RuntimeError('Exit the target game before installing; process IDs: '+str(active))
    sources=[]
    accepted={}
    for mod in receipt['mods']:
        if Path(mod['jar']).name!=mod['jar'] or not mod['jar'].endswith('.jar'):raise RuntimeError('Invalid artifact filename')
        source=bundle/'mods'/mod['jar']
        if digest(source)!=mod['sha256'] or identities(source)!={mod['id']}:raise RuntimeError('Unaccepted artifact: '+mod['jar'])
        sources.append(source)
        accepted[source.name]=mod['sha256']
    previous=[]
    for file in mods.glob('*.jar'):
        ids=identities(file)
        if ids&IDS:
            if ids-IDS:raise RuntimeError('Managed and other mod IDs share a JAR: '+file.name)
            previous.append(file)
    for file in previous:require_closed_jar(file)
    preview={'instance':str(instance),'mods':[p.name for p in sources],
        'previousMods':[p.name for p in previous],
        'allSettingsPreserved':True,'playerWorldsOpened':False}
    if args.prepare_only:print(json.dumps(preview,ensure_ascii=False,indent=2));return
    backup=ROOT/'work/installed-terrain-previous'/datetime.now().strftime('%Y%m%d-%H%M%S-%f')
    backup.mkdir(parents=True);(backup/'mods').mkdir()
    staged=[];moved=[];published=[]
    try:
        for source in sources:
            temp=mods/(source.name+'.terrain-installing')
            if temp.exists():raise RuntimeError('Existing staged artifact must be inspected: '+str(temp))
            staged.append(temp);shutil.copy2(source,temp)
            if digest(temp)!=accepted[source.name]:raise RuntimeError('Staging verification failed')
        for old in previous:
            target=backup/'mods'/old.name
            moved.append((target,old));shutil.move(old,target)
        for temp,source in zip(staged,sources):
            target=mods/source.name
            if target.exists():raise RuntimeError('Unexpected target artifact: '+str(target))
            published.append(target);temp.rename(target)
        for source in sources:
            if digest(mods/source.name)!=accepted[source.name]:raise RuntimeError('Published artifact differs from the accepted bytes')
    except BaseException:
        for file in published:
            if file.exists():file.unlink()
        for old,target in moved:
            if old.exists() and not target.exists():shutil.move(old,target)
        for file in staged:
            if file.exists():file.unlink()
        raise
    preview.update(passed=True,installedAt=datetime.now().isoformat(),backup=str(backup),
        sha256={p.name:digest(mods/p.name) for p in sources},gameLaunched=False,
        dynamicFpsConfigChanged=False,threadpilotManualSettingsPreserved=True)
    output=ROOT/'docs/installation'/('installed-terrain-1.4.1-'+datetime.now().strftime('%Y%m%d')+'.json')
    write(output,preview);print(json.dumps(preview,ensure_ascii=False,indent=2))

if __name__=='__main__':main()

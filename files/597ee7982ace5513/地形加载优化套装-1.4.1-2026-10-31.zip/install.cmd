@echo off
setlocal
for /f "tokens=2 delims=:" %%A in ('chcp') do set "taskCodePage=%%A"
chcp 65001>nul
python -X utf8 "%~dp0tools\install_terrain.py" --bundle "%~dp0." %*
set "taskExit=%errorlevel%"
if not "%taskExit%"=="0" echo Installation failed. Read the error above.
pause
chcp %taskCodePage%>nul
exit /b %taskExit%
